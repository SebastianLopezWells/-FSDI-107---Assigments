import './footer.css';

function Footer(){
    return (
        <div className="footer">
            <h2>    Footer Bar</h2>
        </div>
    );
}

export default  Footer;