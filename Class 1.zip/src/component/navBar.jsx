

function NavBar(){
    return (
        <div className="navbar">
            <h2>Nav Bar</h2>
        </div>
    );
}

export default  NavBar;